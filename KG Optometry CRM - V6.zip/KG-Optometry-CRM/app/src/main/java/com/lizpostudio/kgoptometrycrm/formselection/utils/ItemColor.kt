package com.lizpostudio.kgoptometrycrm.formselection.utils

import android.graphics.Color

object ItemColor {

    private val ITEM_COLOR = mapOf(
        Pair("INFO", "#e5fffa"),
        Pair("FOLLOW UP", "#e5f0ff"),
        Pair("MEMO", "#e5e5ff"),
        Pair("CURRENT / OLD Rx", "#f0e5ff"),
        Pair("REFRACTION", "#fae5ff"),
        Pair("OCULAR HEALTH", "#ffe5fa"),
        Pair("SUPPLEMENTARY TESTS", "#ffe5f0"),
        Pair("CONTACT LENS EXAM", "#fff0e5"),
        Pair("ORTHOK", "#fffae5"),
        Pair("CASH ORDER", "#f0ffe5"),
        Pair("SALES ORDER", "#e5fff0"),
    )

    fun get(sectionName: String) = Color.parseColor(ITEM_COLOR[sectionName])
}