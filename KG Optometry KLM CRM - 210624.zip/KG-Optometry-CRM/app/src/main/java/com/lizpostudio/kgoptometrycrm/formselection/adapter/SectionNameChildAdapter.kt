package com.lizpostudio.kgoptometrycrm.formselection.adapter

import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.lizpostudio.kgoptometrycrm.data.source.local.entity.PatientEntity
import com.lizpostudio.kgoptometrycrm.formselection.utils.ItemColor
import com.lizpostudio.kgoptometrycrm.formselection.viewholder.SectionNameChildViewHolder

class SectionNameChildAdapter(
    private val items: List<PatientEntity>,
    private val onItemClick: (PatientEntity) -> Unit = {}
) : RecyclerView.Adapter<SectionNameChildViewHolder>() {

    override fun getItemCount() = items.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        SectionNameChildViewHolder.create(parent)

    override fun onBindViewHolder(holder: SectionNameChildViewHolder, position: Int) {
        val item = items[position]
        val binding = holder.binding
        binding.reportCard.setBackgroundColor(ItemColor.get(item.sectionName))
        binding.patients = item
        if (item.sectionName == "CASH ORDER") {
            binding.csOrOr.text = if (item.cs.isNotBlank()) " CS ${item.cs}" else " CS -"
        } else if (item.sectionName == "SALES ORDER") {
            binding.csOrOr.text = if (item.or.isNotBlank()) "OR ${item.or}" else "OR -"
        }
        binding.root.setOnClickListener {
            onItemClick(item)
        }
    }
}