package com.lizpostudio.kgoptometrycrm.formselection.utils

import android.graphics.Color

object ItemColor {

    private val ITEM_COLOR = mapOf(
        Pair("INFO", "#EFEBE9"),
        Pair("FOLLOW UP", "#EFEBE9"),
        Pair("MEMO", "#D7CCC8"),
        Pair("CURRENT / OLD Rx", "#D7CCC8"),
        Pair("REFRACTION", "#BCAAA4"),
        Pair("OCULAR HEALTH", "#BCAAA4"),
        Pair("SUPPLEMENTARY TESTS", "#A1887F"),
        Pair("CONTACT LENS EXAM", "#A1887F"),
        Pair("ORTHOK", "#8D6E63"),
        Pair("CASH ORDER", "#8D6E63"),
        Pair("SALES ORDER", "#795548"),
    )

    fun get(sectionName: String) = Color.parseColor(ITEM_COLOR[sectionName])
}