package com.lizpostudio.kgoptometrycrm.search.recycle_bin

import android.view.LayoutInflater
import android.view.ViewGroup
import com.lizpostudio.kgoptometrycrm.data.source.local.entity.PatientEntity
import com.lizpostudio.kgoptometrycrm.databinding.ListItemRecycleBinBinding
import com.lizpostudio.kgoptometrycrm.search.base.BaseSearchAdapter

class SearchRecycleBinAdapter(
    private val onClickIconsRestore: (patientInfo: PatientEntity) -> Unit = {},
    private val onClickIconsDelete: (patientInfo: PatientEntity) -> Unit = {},
    private val onClickItem: (patientInfo: PatientEntity) -> Unit = {},
) : BaseSearchAdapter<ListItemRecycleBinBinding>() {

    init {
        setHasStableIds(true)
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ) = ViewHolder(
        ListItemRecycleBinBinding.inflate(LayoutInflater.from(parent.context), parent, false)
    )

    override fun onBindViewHolder(holder: ViewHolder<ListItemRecycleBinBinding>, position: Int) {
        val item = items[position]
        val binding = holder.binding
        binding.patients = item
        binding.executePendingBindings()
        binding.icDelete.setOnClickListener {
            onClickIconsDelete.invoke(item)
        }
        binding.icRestore.setOnClickListener {
            onClickIconsRestore.invoke(item)
        }
        binding.root.setOnClickListener {
            onClickItem.invoke(item)
        }
    }
}