package com.lizpostudio.kgoptometrycrm.search.data.source.local

import android.util.Log
import androidx.room.withTransaction
import com.lizpostudio.kgoptometrycrm.data.source.local.entity.PatientEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.withContext
import org.json.JSONObject

class RecordDataSourceLocal(private val dao: RecordDao) {

    companion object {
        private const val TAG = "RecordDataSourceLocal"
    }

    suspend fun delete(id: Long) =
        dao.delete(id) > 0

    suspend fun save(data: PatientEntity) =
        dao.insert(data)

    suspend fun clearTableAndSave(jsonData: String?) =
        try {
            val j = JSONObject(jsonData ?: throw NullPointerException())
            val jLength = j.length()
            withContext(Dispatchers.IO) {
                if (jLength > 0) {
                    val jKeys = j.keys()
                    Array(jLength) {
                        val key = synchronized(jKeys) { jKeys.next() }
                        async { PatientEntity.fromJson(key, j.getJSONObject(key)) }
                    }.run { clearTableAndSave(awaitAll(*this)) }
                } else {
                    emptyList()
                }
            }
        } catch (err: Throwable) {
            err.printStackTrace()
            emptyList()
        }

    private suspend fun clearTableAndSave(entities: List<PatientEntity>): List<Long> {
        return dao.roomDatabase.withTransaction {
            val resultDelete = dao.delete()
            if (resultDelete > 0)
                log("Successfully cleared the database, total amount of data cleared $resultDelete")
            else
                log("Not cleared database, database is empty")
            val resultInsert = dao.insert(entities)
            log("${resultInsert.size} new record added to the database")
            resultInsert
        }
    }

    suspend fun delete() = dao.delete()

    fun getRecords(sectionName: String) =
        dao.getRecords(sectionName)

    fun getRecord(recordID: Long) =
        dao.getRecord(recordID)

    private fun log(message: Any?) = synchronized(this) {
        Log.i(TAG, "$message")
    }
}