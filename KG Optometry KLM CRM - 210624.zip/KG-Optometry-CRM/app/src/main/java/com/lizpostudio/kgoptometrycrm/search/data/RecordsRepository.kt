package com.lizpostudio.kgoptometrycrm.search.data

import com.lizpostudio.kgoptometrycrm.data.Resources
import com.lizpostudio.kgoptometrycrm.data.source.local.entity.PatientEntity
import com.lizpostudio.kgoptometrycrm.data.source.remote.firebase.FirebasePath
import com.lizpostudio.kgoptometrycrm.data.source.remote.firebase.RemoteDataSource
import com.lizpostudio.kgoptometrycrm.search.data.source.local.RecordDataSourceLocal
import com.lizpostudio.kgoptometrycrm.search.data.source.remote.service.Connection
import com.lizpostudio.kgoptometrycrm.search.data.source.remote.service.DatabaseService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.channelFlow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.lastOrNull
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

class RecordsRepository private constructor(
    private val remote: RemoteDataSource,
    private val local: RecordDataSourceLocal
) {

    companion object {

        @Volatile
        private var sInstance: RecordsRepository? = null
        fun getInstance(
            remote: RemoteDataSource,
            local: RecordDataSourceLocal
        ) = sInstance ?: synchronized(this) {
            sInstance ?: RecordsRepository(remote, local)
                .also { sInstance = it }
        }
    }

    private val databaseService = DatabaseService {
        remote
            .getFirebaseApp()
            .options
            .databaseUrl
            ?: throw NullPointerException()
    }

    fun getRecords(sectionName: String) =
        local.getRecords(sectionName)

    fun saveFirebaseRecordToDatabase() = channelFlow {
        send(Resources.Loading)
        databaseService.openConnection(
            path = FirebasePath.RECORDS,
            token = getToken(),
        ).collect { conn ->
            val result = when (conn) {
                is Connection.OnLoad -> Resources.Progress(
                    count = conn.progress,
                    length = conn.length
                )
                is Connection.OnSuccess -> local.clearTableAndSave(conn.response)
                    .run { Resources.Success(size) }
                is Connection.OnFailure -> Resources.Error(conn.err)
            }
            send(result)
        }
    }.flowOn(Dispatchers.IO)
        .catch { emit(Resources.Error(it)) }

    suspend fun saveFirebaseRecordToDatabase(
        recordsID: List<Long>,
        onComplete: (success: List<Long>, errors: List<Long>) -> Unit = { _, _ -> },
        onError: (err: Throwable) -> Unit = {}
    ) = withContext(Dispatchers.IO) {
        val dataErrors = mutableListOf<Long>()
        val dataSuccess = mutableListOf<Long>()
        try {
            if (recordsID.isNotEmpty()) {
                val token = getToken()
                val size = recordsID.size
                val dataProcess = Array(size) {
                    async {
                        val key = recordsID[it]
                        val data = databaseService.openConnection(
                            path = FirebasePath.getChildRecords(key),
                            token = token,
                        ).lastOrNull() as? Connection.OnSuccess
                        if (data != null) {
                            val newData = PatientEntity.fromJson(key, data.response)
                            var isDataChange = false
                            if (newData != null) {
                                val oldData = local.getRecord(newData.recordID)
                                if (newData != oldData) {
                                    val resultSave = local.save(newData)
                                    isDataChange = dataSuccess.add(resultSave)
                                }
                            }
                            return@async isDataChange
                        } else {
                            return@async dataErrors.add(key)
                        }
                    }
                }
                awaitAll(*dataProcess)
            }
            withContext(Dispatchers.Main) {
                onComplete.invoke(dataSuccess, dataErrors)
            }
        } catch (err: Throwable) {
            withContext(Dispatchers.Main) {
                onError.invoke(err)
            }
        }
    }

    private suspend fun getToken() = remote
        .getFirebaseAuth()
        .currentUser
        ?.getIdToken(true)
        ?.await()
        ?.token
}